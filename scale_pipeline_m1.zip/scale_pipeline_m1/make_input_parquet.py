#!/usr/bin/env python
"""Build an input parquet by scanning a folder of STL (and optional STEP) files.

Each STL becomes one row: id = filename stem, stl_path = absolute path,
step_path = matching .step in --step-dir (by stem) if present.

  python make_input_parquet.py --stl-dir /data/models --step-dir /data/steps --out input.parquet
"""

import argparse
from pathlib import Path
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description="Scan a folder of meshes -> input parquet")
    ap.add_argument("--stl-dir", required=True, help="folder containing source .stl files (recursive)")
    ap.add_argument("--step-dir", help="optional folder with matching .step files (by filename stem)")
    ap.add_argument("--out", default="input.parquet")
    ap.add_argument("--category", default="", help="optional constant category tag for every row")
    ap.add_argument("--license", default="", help="optional constant license tag for every row")
    args = ap.parse_args()

    stl_dir = Path(args.stl_dir)
    if not stl_dir.is_dir():
        raise SystemExit(f"--stl-dir not found: {stl_dir}")
    step_dir = Path(args.step_dir) if args.step_dir else None

    stls = sorted(set(list(stl_dir.rglob("*.stl")) + list(stl_dir.rglob("*.STL"))))
    rows, seen, dups, n_step = [], set(), 0, 0
    for p in stls:
        stem = p.stem
        if stem in seen:
            dups += 1
            stem = f"{p.parent.name}__{stem}"
        seen.add(stem)
        step = ""
        if step_dir:
            cand = step_dir / f"{p.stem}.step"
            if cand.exists():
                step = str(cand.resolve())
                n_step += 1
        rows.append({"id": stem, "stl_path": str(p.resolve()), "step_path": step,
                     "category": args.category, "license": args.license})

    if not rows:
        raise SystemExit(f"No .stl files found under {stl_dir}")

    pd.DataFrame(rows).to_parquet(args.out, index=False)
    print(f"Wrote {args.out}: {len(rows)} rows ({n_step} with STEP"
          + (f", {dups} stem collisions disambiguated" if dups else "") + ")")


if __name__ == "__main__":
    main()
