# Milestone 1 — Scaling Augmentation Pipeline

This tool reads a Parquet table of source CAD models, generates scaled variants of
each one, validates and repairs the meshes, removes duplicates, balances the output
by size, and writes the results with a manifest.

It is organized so that later milestones (rotation, mirror, feature edits) can be
added as new operation classes without changing the rest of the pipeline.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

pymeshlab is used for self-intersection detection and repair. cadquery is used for
STEP input/output. Both are in requirements.txt. If you only need STL you can leave
cadquery out.

## Run

Try the bundled example first. It contains 12 models and runs out of the box:

```bash
python scale_augment.py --input example/example.parquet --output-dir outputs
```

Then on your own data:

```bash
# build a parquet from a folder of meshes (skip if you already have one)
python make_input_parquet.py --stl-dir /data/models --step-dir /data/steps --out input.parquet

# check the input without processing anything
python scale_augment.py --input input.parquet --dry-run

# trial run on the first 20 models
python scale_augment.py --input input.parquet --output-dir outputs --limit 20

# full run
python scale_augment.py --input input.parquet --output-dir outputs

# clean/repair meshes without scaling
python scale_augment.py --input input.parquet --output-dir cleaned --repair-only
```

One command runs the whole pipeline: load, scale, validate, repair, dedup, balance,
write STL (and STEP), and write the manifest. Progress is logged as it goes, and a
single bad model is logged and skipped rather than aborting the run.

## Input parquet

One row per source model. The columns are:

| Column | Required | Type | Meaning |
|--------|----------|------|---------|
| `id` | yes | string | unique identifier for the source model |
| `stl_path` | yes | string | local path or http(s) URL to the source STL |
| `step_path` | no | string | local path or URL to a source STEP; if present, a scaled STEP is written next to each STL |
| `bbox_x`, `bbox_y`, `bbox_z` | no | float | source bbox in mm (informational; the pipeline measures its own) |
| `category` | no | string | free-form tag, carried into the manifest |
| `license` | no | string | carried into the manifest |

Example row:

```
id=part_0001
stl_path=/data/models/part_0001.stl
step_path=/data/models/part_0001.step
bbox_x=80.0  bbox_y=40.0  bbox_z=8.0
category=bracket   license=CC-BY 3.0
```

On load the schema is checked. If a required column is missing or an `stl_path` does
not resolve, the run stops with a clear error instead of skipping silently.

The required column names are configurable. If your file calls them something else
(for example `uuid` or `mesh_file`), set `input.required_columns` in
`config/default.yaml`. No code change is needed.

You choose the input either on the command line (`--input path.parquet`) or in the
config (`input.parquet`). The command line wins if both are set. Relative paths in
the parquet resolve against `input.base_dir`.

Each `stl_path` / `step_path` can be a local path or an http(s) URL. URLs are
downloaded once and cached under `<output>/_download_cache`. Local files are read in
place and nothing is uploaded.

## How it works

```
parquet -> load + schema check -> scale -> validate -> pass ------------------> shipped/
                                                     -> fail -> repair -> pass -> repaired_passed/
                                                                       -> fail -> quarantine/
                                  then: dedup -> balance -> write STL (+STEP) + manifest
```

1. Load and schema-check. Read the parquet and stop early on missing columns or
   unresolved paths.
2. Scaling. Three operations, each can be turned off:
   - Proportional: one uniform factor on all axes. Default `[0.7, 0.85, 1.15, 1.3]`.
   - Non-proportional: independent per-axis factors, including the X/Y diagonal
     `(1.5, 1.5, 1.0)` that scales X and Y together while Z stays fixed.
   - Small-part upscale: extra large factors for parts whose smallest dimension is
     below `threshold_mm`, capped at `max_output_mm`, skipping `protected_ids`.
3. Validation. Each output is checked for NaN/Inf, watertightness, winding
   consistency, degenerate or zero-area faces, self-intersections, disconnected
   components, and inverted normals. Meshes that pass untouched go to `shipped/`.
4. Repair (only on failure). A mesh that fails validation is repaired (weld
   vertices, drop degenerate and duplicate faces, fix normals, fill small holes,
   remove self-intersecting faces) and validated again. If it passes it goes to
   `repaired_passed/`, otherwise to `quarantine/`. Clean meshes are never altered.
   The mode is configurable (`on_failure` default, `all`, or `off`).
5. Dedup. Each mesh gets a geometry signature (normalized vertex hash plus face and
   vertex count, volume, and bbox). True duplicates are dropped; different scales of
   the same part survive.
6. Balance. Outputs are bucketed by size and each bucket is capped so the result is
   not skewed toward many tiny and many huge models. Before/after counts are logged.
7. Write and manifest. Pristine meshes go to `shipped/`, repaired ones to
   `repaired_passed/`, each as STL plus a scaled STEP when the source has a
   `step_path`. A `manifest.parquet` and `manifest.csv` record one row per output.

## Configuration

All settings live in [`config/default.yaml`](config/default.yaml). CLI flags
override the config.

CLI flags:

| Flag | Effect |
|------|--------|
| `--config PATH` | YAML config (default `config/default.yaml`) |
| `--input PATH` | input parquet (overrides `input.parquet`) |
| `--base-dir PATH` | base dir for resolving relative source paths |
| `--output-dir PATH` | output dir (overrides `output.dir`) |
| `--seed N` | RNG seed for the balancing subsample |
| `--limit N` | process only the first N sources |
| `--dry-run` | check schema and paths, then exit |
| `--repair-only` | clean/repair sources without scaling (no balance or dedup) |
| `--print-config` | print the resolved config and exit |
| `--quiet` | only warnings and errors |
| `--version` | print version and exit |
| `--no-proportional` | turn off proportional scaling |
| `--no-nonproportional` | turn off non-proportional scaling |
| `--no-upscale` | turn off the small-part upscale tier |
| `--no-balance` | turn off size balancing |
| `--no-dedup` | turn off dedup |
| `--no-repair` | turn off repair |
| `--no-step` | do not write STEP files |
| `--no-self-intersection` | skip the self-intersection check (faster) |
| `-v`, `--verbose` | debug logging |

Main config sections:

- `operations.proportional.factors`: list of uniform factors.
- `operations.non_proportional.combos`: list of `[sx, sy, sz]`.
- `operations.small_part_upscale`: `threshold_mm`, `max_output_mm`, `factors`.
- `repair`: `mode` (`off`, `on_failure`, `all`), `use_pymeshlab`, per-fix toggles.
- `validation`: per-check toggles and thresholds, including `require_watertight`,
  `max_self_intersections`, `require_single_component`, `reject_inverted_normals`.
- `balance`: `bucket_edges_mm`, `mode` (`min` or `fixed`), `target_per_bucket`.

## Output

```
outputs/
  shipped/                 passed validation untouched (STL + STEP)
  repaired_passed/         passed only after repair (STL + STEP)
  quarantine/              repair could not fix; not shipped
  manifest.parquet         one row per generated output
  manifest.csv
  distribution_report.json counts and before/after size distribution
```

Manifest columns: `source_id, operation, params, suffix, bbox_x/y/z, max_dim,
volume, repaired, repair_actions, watertight, winding_consistent, degenerate_faces,
self_intersections, self_intersection_checked, components, normals_outward, nan_inf,
valid, reasons, size_bucket, status, output_path, output_step`.

The `status` column is one of `shipped`, `repaired_passed`, `quarantined`,
`duplicate`, `dropped_by_balance`, `source_load_error`, `operation_error`, or
`processing_error`. A single bad source or variant is recorded with an error status
and the run continues.

## Tests

```bash
python -m pytest tests/ -q
```

## Adding new operations

Subclass `scale_pipeline.operations.base.BaseOperation`, implement
`generate(mesh, source_meta, cfg) -> list[Variant]`, and register it in
`operations/build_operations()`. Validation, repair, dedup, balancing, the manifest,
and STEP export all apply automatically.

STEP scaling lives in `step_io.py`. For an operation whose parameters are not a pure
scale (for example rotation), add the matching transform there and extend
`step_io.scale_vector_from_params`.
