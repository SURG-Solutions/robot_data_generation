"""Load YAML config, apply CLI overrides, validate structure."""

import copy
from pathlib import Path
import yaml


class ConfigError(Exception):
    pass


_REQUIRED_SECTIONS = ["input", "output", "operations", "repair", "validation", "dedup", "balance"]


def load_config(yaml_path, overrides=None):
    """Read the YAML config and apply a flat dict of dotted-key overrides.

    Example override key: "operations.proportional.enabled" -> False
    """
    path = Path(yaml_path)
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    with open(path) as f:
        cfg = yaml.safe_load(f)

    for section in _REQUIRED_SECTIONS:
        if section not in cfg:
            raise ConfigError(f"Config missing required section: '{section}'")

    if overrides:
        for dotted, value in overrides.items():
            if value is None:
                continue
            _set_dotted(cfg, dotted, value)

    _validate(cfg)
    return cfg


def _set_dotted(cfg, dotted, value):
    keys = dotted.split(".")
    node = cfg
    for k in keys[:-1]:
        if k not in node or not isinstance(node[k], dict):
            node[k] = {}
        node = node[k]
    node[keys[-1]] = value


def _validate(cfg):
    pf = cfg["operations"]["proportional"]["factors"]
    if not isinstance(pf, list) or not all(isinstance(x, (int, float)) and x > 0 for x in pf):
        raise ConfigError("operations.proportional.factors must be a list of positive numbers")

    for combo in cfg["operations"]["non_proportional"]["combos"]:
        if len(combo) != 3 or not all(isinstance(x, (int, float)) and x > 0 for x in combo):
            raise ConfigError(f"non_proportional combo must be 3 positive numbers, got {combo}")

    up = cfg["operations"]["small_part_upscale"]
    if up["threshold_mm"] <= 0 or up["max_output_mm"] <= 0:
        raise ConfigError("small_part_upscale threshold_mm and max_output_mm must be positive")

    edges = cfg["balance"]["bucket_edges_mm"]
    if list(edges) != sorted(edges):
        raise ConfigError("balance.bucket_edges_mm must be ascending")
    if cfg["balance"]["mode"] not in ("min", "fixed"):
        raise ConfigError("balance.mode must be 'min' or 'fixed'")
    if cfg["balance"]["mode"] == "fixed" and not cfg["balance"].get("target_per_bucket"):
        raise ConfigError("balance.mode 'fixed' requires balance.target_per_bucket")

    return True


def snapshot(cfg):
    """Deep copy of the resolved config, for embedding in run reports."""
    return copy.deepcopy(cfg)
