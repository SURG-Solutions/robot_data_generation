"""Mesh-integrity validation. Never let a defective mesh ship.

Pure-trimesh checks: NaN/Inf, watertight, winding consistency, degenerate faces.
Self-intersection: best-effort via pymeshlab (filter names vary across versions;
falls back to "not checked" rather than crashing)."""

import numpy as np


def make_self_intersection_checker():
    """Return a callable(mesh)->int|None, or None if pymeshlab is unavailable.

    int  = number of self-intersecting faces
    None = could not be evaluated (pymeshlab missing or no compatible filter)
    """
    try:
        import pymeshlab
    except Exception:
        return None

    candidate_filters = [
        "compute_selection_by_self_intersections_per_face",
        "select_self_intersecting_faces",
    ]

    def check(mesh):
        try:
            ms = pymeshlab.MeshSet()
            ms.add_mesh(pymeshlab.Mesh(
                vertex_matrix=np.asarray(mesh.vertices, dtype=np.float64),
                face_matrix=np.asarray(mesh.faces, dtype=np.int32)))
        except Exception:
            return None
        for fname in candidate_filters:
            try:
                ms.apply_filter(fname)
                return int(ms.current_mesh().selected_face_number())
            except Exception:
                continue
        return None

    return check


def validate_mesh(mesh, cfg, self_intersection_checker=None):
    """Return a flags dict including 'valid' (bool) and 'reasons' (list[str])."""
    rules = cfg["validation"]
    v = np.asarray(mesh.vertices)

    flags = {
        "n_vertices": int(len(mesh.vertices)),
        "n_faces": int(len(mesh.faces)),
        "watertight": bool(mesh.is_watertight),
        "winding_consistent": bool(mesh.is_winding_consistent),
        "nan_inf": bool(not np.isfinite(v).all()),
    }

    areas = np.asarray(mesh.area_faces)
    flags["degenerate_faces"] = int((areas <= rules["min_face_area"]).sum())

    try:
        flags["components"] = int(mesh.body_count)
    except Exception:
        flags["components"] = 1

    flags["normals_outward"] = True
    try:
        if mesh.is_watertight and float(mesh.volume) < 0:
            flags["normals_outward"] = False
    except Exception:
        pass

    si = None
    if rules["check_self_intersection"] and self_intersection_checker is not None:
        si = self_intersection_checker(mesh)
    flags["self_intersections"] = si

    reasons = []
    if rules["reject_nan_inf"] and flags["nan_inf"]:
        reasons.append("nan_inf")
    if rules["require_watertight"] and not flags["watertight"]:
        reasons.append("not_watertight")
    if rules["require_winding_consistent"] and not flags["winding_consistent"]:
        reasons.append("winding_inconsistent")
    if flags["degenerate_faces"] > rules["max_degenerate_faces"]:
        reasons.append("degenerate_faces")
    if si is not None and si > rules["max_self_intersections"]:
        reasons.append("self_intersections")
    if rules.get("require_single_component") and flags["components"] > 1:
        reasons.append("multiple_components")
    if rules.get("reject_inverted_normals") and not flags["normals_outward"]:
        reasons.append("inverted_normals")

    flags["self_intersection_checked"] = si is not None
    flags["valid"] = len(reasons) == 0
    flags["reasons"] = reasons
    return flags
