"""STL read/write via trimesh. STEP is a documented extension point (needs CadQuery)."""

from pathlib import Path
import trimesh


class MeshLoadError(Exception):
    pass


def load_mesh(path):
    """Load an STL into a single trimesh.Trimesh. Scenes are merged to one mesh."""
    p = Path(path)
    if not p.exists():
        raise MeshLoadError(f"Mesh file not found: {p}")
    try:
        obj = trimesh.load(str(p), force="mesh", process=False)
    except Exception as e:
        raise MeshLoadError(f"Failed to load {p}: {e}")
    if obj is None or not hasattr(obj, "vertices") or len(obj.vertices) == 0:
        raise MeshLoadError(f"Empty or unreadable mesh: {p}")
    return obj


def save_mesh(mesh, path, binary=True):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    mesh.export(str(p), file_type="stl_ascii" if not binary else "stl")
    return p


def bbox_dims(mesh):
    """Axis-aligned bounding-box extents [dx, dy, dz] in model units."""
    return [float(x) for x in mesh.extents]


def mesh_volume(mesh):
    """Signed-volume magnitude; 0 for non-volumetric meshes."""
    try:
        if mesh.is_volume:
            return abs(float(mesh.volume))
    except Exception:
        pass
    return 0.0


def load_step(path):  # pragma: no cover
    raise NotImplementedError("STEP I/O lives in step_io.py (requires CadQuery).")
