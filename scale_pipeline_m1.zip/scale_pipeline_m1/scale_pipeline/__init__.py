"""Milestone 1 scaling-augmentation pipeline: parquet in -> validated, balanced, deduped scaled meshes out."""

__version__ = "1.0.0"
