"""Mesh repair: try to fix common defects before validation so clean-able meshes ship.

Order matters — cheap topological fixes (trimesh) first, then optional heavier
self-intersection resolution (pymeshlab). Repair is best-effort and never raises;
a mesh that can't be fixed simply fails validation afterward and is quarantined."""

import logging
import numpy as np

log = logging.getLogger("scale_pipeline.repair")


def _trimesh_repair(mesh, cfg, allow_fill=True):
    """Topology cleanup that doesn't change the intended shape.

    allow_fill=False is used for the post-pymeshlab sweep: after self-intersecting
    faces are deleted the mesh has intentional gaps, and re-filling them tends to
    create new degenerate triangles, so we only sweep slivers/normals there."""
    actions = []
    m = mesh.copy()

    if cfg["repair"]["merge_vertices"]:
        before = len(m.vertices)
        m.merge_vertices()
        if len(m.vertices) != before:
            actions.append(f"merged_vertices({before}->{len(m.vertices)})")

    if cfg["repair"]["remove_degenerate_faces"]:
        before = len(m.faces)
        area_thresh = cfg.get("validation", {}).get(
            "min_face_area", cfg["repair"].get("degenerate_height", 1.0e-6))
        mask = np.asarray(m.area_faces) > area_thresh
        if int(mask.sum()) != before:
            m.update_faces(mask)
            m.remove_unreferenced_vertices()
            actions.append(f"removed_degenerate({before - int(mask.sum())})")

    if cfg["repair"]["remove_duplicate_faces"]:
        before = len(m.faces)
        m.update_faces(m.unique_faces())
        if len(m.faces) != before:
            actions.append(f"removed_duplicate_faces({before - len(m.faces)})")

    if cfg["repair"]["remove_unreferenced_vertices"]:
        m.remove_unreferenced_vertices()

    if cfg["repair"]["fix_normals"]:
        m.fix_normals()
        actions.append("fixed_normals")

    if allow_fill and cfg["repair"]["fill_holes"]:
        try:
            if not m.is_watertight:
                m.fill_holes()
                if m.is_watertight:
                    actions.append("filled_holes")
        except Exception:
            pass

    return m, actions


def _pymeshlab_repair(mesh, cfg):
    """Heavier repair incl. self-intersection removal. Best-effort; returns (mesh, actions)."""
    try:
        import pymeshlab
    except Exception:
        return mesh, []

    actions = []
    try:
        ms = pymeshlab.MeshSet()
        ms.add_mesh(pymeshlab.Mesh(
            vertex_matrix=np.asarray(mesh.vertices, dtype=np.float64),
            face_matrix=np.asarray(mesh.faces, dtype=np.int32)))
    except Exception:
        return mesh, []

    repair_filters = [
        "meshing_remove_duplicate_vertices",
        "meshing_remove_duplicate_faces",
        "meshing_remove_null_faces",
        "meshing_repair_non_manifold_edges",
        "meshing_repair_non_manifold_vertices",
    ]
    if cfg["repair"]["resolve_self_intersections"]:
        repair_filters.append("meshing_remove_selected_faces")

    for fname in repair_filters:
        try:
            if fname == "meshing_remove_selected_faces":
                for sel in ("compute_selection_by_self_intersections_per_face",
                            "select_self_intersecting_faces"):
                    try:
                        ms.apply_filter(sel)
                        break
                    except Exception:
                        continue
            ms.apply_filter(fname)
            actions.append(fname)
        except Exception:
            continue

    try:
        import trimesh
        cur = ms.current_mesh()
        out = trimesh.Trimesh(vertex_matrix := cur.vertex_matrix(),
                              cur.face_matrix(), process=False)
        return out, actions
    except Exception:
        return mesh, actions


def repair_mesh(mesh, cfg):
    """Return (repaired_mesh, list_of_actions). No-op (with empty actions) if disabled.

    Order: trimesh cleanup -> pymeshlab (incl. self-intersection face deletion) ->
    a second trimesh cleanup, because deleting self-intersecting faces can leave
    new slivers / boundary edges / winding flips that the first pass never saw."""
    if not cfg["repair"]["enabled"]:
        return mesh, []
    m, actions = _trimesh_repair(mesh, cfg)
    if cfg["repair"]["use_pymeshlab"]:
        m, pml = _pymeshlab_repair(m, cfg)
        actions += pml
        m, post = _trimesh_repair(m, cfg, allow_fill=False)
        actions += [f"post_{a}" for a in post]
    return m, actions
