"""Size-bucket balancing. Stops the output skewing to 'lots of tiny + lots of huge'
by bucketing on size and capping each bucket. Reports before/after distribution."""

import random


def bucket_index(value, edges):
    """edges ascending; returns 0..len(edges). Bucket label is human-readable via bucket_label."""
    for i, e in enumerate(edges):
        if value < e:
            return i
    return len(edges)


def bucket_label(i, edges):
    lo = "0" if i == 0 else str(edges[i - 1])
    hi = str(edges[i]) if i < len(edges) else "inf"
    return f"{lo}-{hi}mm"


def balance(records, cfg, seed):
    """records: list of dicts each with 'max_dim'. Returns (kept, report).

    report has per-bucket before/after counts and the cap that was applied.
    """
    b = cfg["balance"]
    edges = b["bucket_edges_mm"]
    rng = random.Random(seed)

    buckets = {}
    for r in records:
        bi = bucket_index(r["max_dim"], edges)
        buckets.setdefault(bi, []).append(r)

    before = {bucket_label(bi, edges): len(items) for bi, items in sorted(buckets.items())}

    if not b["enabled"] or not buckets:
        kept = list(records)
        report = {"enabled": b["enabled"], "mode": b["mode"], "cap": None,
                  "before": before, "after": before, "edges": edges}
        return kept, report

    if b["mode"] == "min":
        cap = min(len(items) for items in buckets.values())
    else:
        cap = int(b["target_per_bucket"])

    kept = []
    after = {}
    for bi, items in sorted(buckets.items()):
        sel = items if len(items) <= cap else rng.sample(items, cap)
        after[bucket_label(bi, edges)] = len(sel)
        kept.extend(sel)

    report = {"enabled": True, "mode": b["mode"], "cap": cap,
              "before": before, "after": after, "edges": edges}
    return kept, report


def format_report(report):
    """Human-readable before/after table for logging."""
    lines = [f"Size-distribution balancing (mode={report['mode']}, cap={report['cap']}):",
             f"  {'bucket':>14} | {'before':>7} | {'after':>7}"]
    labels = list(report["before"].keys())
    for lab in labels:
        lines.append(f"  {lab:>14} | {report['before'].get(lab,0):>7} | {report['after'].get(lab,0):>7}")
    tb = sum(report["before"].values())
    ta = sum(report["after"].values())
    lines.append(f"  {'TOTAL':>14} | {tb:>7} | {ta:>7}")
    return "\n".join(lines)
