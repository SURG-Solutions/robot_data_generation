"""STEP (BREP) scaling via CadQuery/OCP. Exact geometry — no mesh defects by construction.

Used to emit a scaled STEP alongside the scaled STL for any source that supplies a
resolvable step_path. The scale vector is taken from the operation params so the
STEP matches its STL sibling exactly."""

import logging

log = logging.getLogger("scale_pipeline.step_io")

try:
    import cadquery as cq
    from OCP.gp import gp_GTrsf, gp_Mat
    from OCP.BRepBuilderAPI import BRepBuilderAPI_GTransform
    _AVAILABLE = True
except Exception:  # pragma: no cover - exercised only when cadquery is absent
    _AVAILABLE = False


def available():
    return _AVAILABLE


def scale_vector_from_params(op, params):
    """Map an operation's params to a (sx, sy, sz) scale vector."""
    if op == "identity":
        return (1.0, 1.0, 1.0)
    if op in ("proportional", "small_part_upscale"):
        f = float(params["factor"])
        return (f, f, f)
    if op == "non_proportional":
        return (float(params["sx"]), float(params["sy"]), float(params["sz"]))
    raise ValueError(f"No scale vector for operation '{op}'")


def load_step(path):
    return cq.importers.importStep(str(path)).val()


def scale_step(solid, sx, sy, sz):
    g = gp_GTrsf()
    g.SetVectorialPart(gp_Mat(sx, 0, 0, 0, sy, 0, 0, 0, sz))
    return cq.Shape.cast(BRepBuilderAPI_GTransform(solid.wrapped, g, True).Shape())


def save_step(solid, path):
    cq.exporters.export(cq.Workplane().add(solid), str(path), exportType="STEP")
    return path
