"""Geometry-signature dedup: catch true duplicates without dropping legitimately distinct scales.

Signature = face count + vertex count + rounded volume + rounded bbox aspect +
a hash of the order-independent, position/scale-normalized vertex cloud.
Two meshes that are the same shape at the same size collapse to one signature;
a 1.3x scale of a part has a different bbox/volume so it survives."""

import hashlib
import numpy as np


def signature(mesh, cfg):
    d = cfg["dedup"]
    v = np.asarray(mesh.vertices, dtype=np.float64)
    ext = np.asarray(mesh.extents, dtype=np.float64)

    n_faces = int(len(mesh.faces))
    n_verts = int(len(mesh.vertices))

    try:
        vol = abs(float(mesh.volume)) if mesh.is_volume else 0.0
    except Exception:
        vol = 0.0
    vol_r = round(vol, d["volume_round"])

    bbox_r = tuple(round(float(x), d["bbox_round"]) for x in ext)

    mn = v.min(axis=0)
    scale = max(float(ext.max()), 1e-9)
    norm = (v - mn) / scale
    q = np.round(norm, d["vertex_decimals"]).astype(np.float32)
    idx = np.lexsort((q[:, 2], q[:, 1], q[:, 0]))
    digest = hashlib.sha256(q[idx].tobytes()).hexdigest()[:16]

    return f"{n_faces}_{n_verts}_{vol_r}_{bbox_r[0]}x{bbox_r[1]}x{bbox_r[2]}_{digest}"


class Deduplicator:
    def __init__(self, cfg):
        self.cfg = cfg
        self.seen = {}
        self.enabled = cfg["dedup"]["enabled"]

    def check(self, mesh, label=None):
        """Return (is_duplicate: bool, signature: str, original_label)."""
        sig = signature(mesh, self.cfg)
        if not self.enabled:
            return False, sig, None
        if sig in self.seen:
            return True, sig, self.seen[sig]
        self.seen[sig] = label
        return False, sig, None
