"""Parquet input loader (schema-validated, fail-fast) and output manifest writer."""

from pathlib import Path
import pandas as pd

from .fetch import is_url


class SchemaError(Exception):
    pass


def load_sources(cfg):
    """Validate and load the input parquet. Returns list[dict] of source records.

    Fails fast (SchemaError) on missing columns or unresolved paths.
    """
    inp = cfg["input"]
    parquet = inp.get("parquet")
    if not parquet:
        raise SchemaError("input.parquet is not set (pass --input or set it in the config)")
    ppath = Path(parquet)
    if not ppath.exists():
        raise SchemaError(f"Input parquet not found: {ppath}")

    df = pd.read_parquet(ppath)

    missing = [c for c in inp["required_columns"] if c not in df.columns]
    if missing:
        raise SchemaError(
            f"Input parquet missing required columns {missing}. Found columns: {list(df.columns)}")

    base = Path(inp["base_dir"])
    records, unresolved = [], []
    for _, row in df.iterrows():
        raw = str(row["stl_path"])
        if is_url(raw):
            stl_ref = raw
        else:
            stl = Path(raw)
            if not stl.is_absolute():
                stl = base / stl
            if not stl.exists():
                unresolved.append(str(stl))
                continue
            stl_ref = str(stl)
        rec = {"id": str(row["id"]), "stl_path": stl_ref}
        for opt in inp.get("optional_columns", []):
            if opt in df.columns:
                rec[opt] = row[opt]
        records.append(rec)

    if unresolved and inp.get("fail_on_unresolved_paths", True):
        raise SchemaError(
            f"{len(unresolved)} source paths do not resolve. Examples: {unresolved[:3]}")

    if not records:
        raise SchemaError("No resolvable source rows in input parquet.")
    return records


def write_manifest(rows, out_dir, basename):
    """Write the output manifest as both parquet and csv. Returns the two paths."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    pq = out_dir / f"{basename}.parquet"
    csv = out_dir / f"{basename}.csv"
    df.to_parquet(pq, index=False)
    df.to_csv(csv, index=False)
    return pq, csv
