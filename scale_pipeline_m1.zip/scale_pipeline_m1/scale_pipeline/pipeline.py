"""Orchestrator: load -> scale -> validate -> dedup -> balance -> write + manifest + report."""

import json
import logging
from pathlib import Path

from . import mesh_io
from . import step_io
from . import fetch
from .operations import build_operations
from .validation import validate_mesh, make_self_intersection_checker
from .repair import repair_mesh
from .dedup import Deduplicator
from .balance import balance, format_report
from .io_parquet import load_sources, write_manifest

log = logging.getLogger("scale_pipeline")


def _export_step(src, var, out_name, shipped_dir, out_root, step_cache, cache_dir):
    """Scale the source STEP by the variant's scale vector and export it. Best-effort."""
    step_src = src.get("step_path")
    if not step_src or str(step_src).strip() in ("", "nan", "None"):
        return None
    from pathlib import Path
    if not fetch.is_url(step_src) and not Path(str(step_src)).exists():
        return None
    try:
        sid = src["id"]
        if sid not in step_cache:
            step_cache[sid] = step_io.load_step(fetch.to_local(step_src, cache_dir))
        sx, sy, sz = step_io.scale_vector_from_params(var.op, var.params)
        scaled = step_io.scale_step(step_cache[sid], sx, sy, sz)
        step_name = out_name.rsplit(".", 1)[0] + ".step"
        sp = step_io.save_step(scaled, shipped_dir / step_name)
        return str(Path(sp).relative_to(out_root))
    except Exception as e:
        log.warning("STEP export failed for %s: %s", out_name, str(e)[:120])
        return None


def run(cfg):
    out_root = Path(cfg["output"]["dir"])
    shipped_dir = out_root / cfg["output"]["shipped_subdir"]
    repaired_dir = out_root / cfg["output"]["repaired_subdir"]
    quar_dir = out_root / cfg["output"]["quarantine_subdir"]
    shipped_dir.mkdir(parents=True, exist_ok=True)
    repaired_dir.mkdir(parents=True, exist_ok=True)
    quar_dir.mkdir(parents=True, exist_ok=True)
    binary = cfg["output"]["stl_binary"]
    repair_mode = cfg["repair"]["mode"] if cfg["repair"]["enabled"] else "off"
    cache_dir = cfg["input"].get("download_dir") or (out_root / "_download_cache")

    sources = load_sources(cfg)
    log.info("Loaded %d source models from parquet", len(sources))

    ops = build_operations(cfg)
    log.info("Enabled operations: %s", [o.name for o in ops])

    dedup = Deduplicator(cfg)
    si_checker = make_self_intersection_checker()
    if cfg["validation"]["check_self_intersection"] and si_checker is None:
        log.warning("Self-intersection check requested but pymeshlab unavailable -> skipped")

    manifest = []
    candidates = []
    n_quar = n_dup = n_valid = 0

    def fill_flags(row, flags):
        row.update({
            "watertight": flags["watertight"],
            "winding_consistent": flags["winding_consistent"],
            "degenerate_faces": flags["degenerate_faces"],
            "self_intersections": flags["self_intersections"],
            "self_intersection_checked": flags["self_intersection_checked"],
            "components": flags["components"],
            "normals_outward": flags["normals_outward"],
            "nan_inf": flags["nan_inf"],
            "valid": flags["valid"],
            "reasons": ";".join(flags["reasons"]),
        })

    def fill_geom(row, mesh):
        dims = mesh_io.bbox_dims(mesh)
        row["bbox_x"], row["bbox_y"], row["bbox_z"] = (round(dims[0], 3), round(dims[1], 3), round(dims[2], 3))
        row["max_dim"] = round(max(dims), 3)
        row["volume"] = round(mesh_io.mesh_volume(mesh), 3)

    limit = cfg.get("limit") or 0
    if limit and limit < len(sources):
        log.info("Limiting to first %d of %d sources (--limit)", limit, len(sources))
        sources = sources[:limit]

    total = len(sources)
    n_err = 0
    log_every = max(1, total // 20)

    for i, src in enumerate(sources, 1):
        try:
            base_mesh = mesh_io.load_mesh(fetch.to_local(src["stl_path"], cache_dir))
        except Exception as e:
            log.error("Skip source %s: %s", src["id"], e)
            manifest.append({"source_id": src["id"], "operation": "load", "status": "source_load_error",
                             "error": str(e)[:200]})
            n_err += 1
            continue

        for op in ops:
            try:
                variants = op.generate(base_mesh, src, cfg)
            except Exception as e:
                log.error("op %s failed on source %s: %s", op.name, src["id"], str(e)[:150])
                manifest.append({"source_id": src["id"], "operation": op.name,
                                 "status": "operation_error", "error": str(e)[:200]})
                n_err += 1
                continue

            for var in variants:
                out_name = f"{src['id']}__{var.suffix}.stl"
                row = {
                    "source_id": src["id"], "operation": var.op,
                    "params": json.dumps(var.params), "suffix": var.suffix,
                    "repaired": False, "repair_actions": "",
                    "size_bucket": None, "status": None,
                    "output_path": None, "output_step": None,
                }
                try:
                    mesh = var.mesh
                    if repair_mode == "all":
                        mesh, actions = repair_mesh(mesh, cfg)
                        row["repaired"] = bool(actions)
                        row["repair_actions"] = ";".join(actions)

                    flags = validate_mesh(mesh, cfg, si_checker)

                    if not flags["valid"] and repair_mode == "on_failure":
                        mesh, actions = repair_mesh(mesh, cfg)
                        flags = validate_mesh(mesh, cfg, si_checker)
                        row["repaired"] = True
                        row["repair_actions"] = ";".join(actions)

                    fill_geom(row, mesh)
                    fill_flags(row, flags)

                    if not flags["valid"]:
                        p = mesh_io.save_mesh(mesh, quar_dir / out_name, binary)
                        row["status"] = "quarantined"
                        row["output_path"] = str(p.relative_to(out_root))
                        n_quar += 1
                        manifest.append(row)
                        continue

                    is_dup, sig, original = dedup.check(mesh, label=out_name)
                    if is_dup:
                        row["status"] = "duplicate"
                        row["duplicate_of"] = original
                        n_dup += 1
                        manifest.append(row)
                        continue

                    n_valid += 1
                    candidates.append((row, mesh, out_name, src, var))
                except Exception as e:
                    log.error("variant %s__%s failed: %s", src["id"], var.suffix, str(e)[:150])
                    row["status"] = "processing_error"
                    row["error"] = str(e)[:200]
                    manifest.append(row)
                    n_err += 1
                    continue

        if i % log_every == 0 or i == total:
            log.info("  %d/%d sources  (valid=%d quarantined=%d errors=%d)",
                     i, total, n_valid, n_quar, n_err)

    cand_records = [r for (r, _m, _n, _s, _v) in candidates]
    kept, report = balance(cand_records, cfg, cfg["seed"])
    kept_ids = {id(r) for r in kept}

    from .balance import bucket_index, bucket_label
    edges = cfg["balance"]["bucket_edges_mm"]
    want_step = cfg["output"].get("export_step", False) and step_io.available()
    step_cache = {}
    n_ship = n_repaired = n_drop = n_step = 0
    for (row, mesh, out_name, src, var) in candidates:
        row["size_bucket"] = bucket_label(bucket_index(row["max_dim"], edges), edges)
        if id(row) not in kept_ids:
            row["status"] = "dropped_by_balance"
            n_drop += 1
            manifest.append(row)
            continue

        if row["repaired"]:
            dest_dir, status = repaired_dir, "repaired_passed"
            n_repaired += 1
        else:
            dest_dir, status = shipped_dir, "shipped"
            n_ship += 1
        p = mesh_io.save_mesh(mesh, dest_dir / out_name, binary)
        row["status"] = status
        row["output_path"] = str(p.relative_to(out_root))
        if want_step:
            sp = _export_step(src, var, out_name, dest_dir, out_root, step_cache, cache_dir)
            if sp:
                row["output_step"] = sp
                n_step += 1
        manifest.append(row)

    pq, csv = write_manifest(manifest, out_root, cfg["output"]["manifest_basename"])

    dist_report = {
        "sources": len(sources),
        "generated_valid_unique": n_valid,
        "shipped_pristine": n_ship,
        "repaired_passed": n_repaired,
        "shipped_step": n_step,
        "dropped_by_balance": n_drop,
        "quarantined": n_quar,
        "duplicates": n_dup,
        "errors": n_err,
        "repair_mode": repair_mode,
        "balance": report,
    }
    (out_root / "distribution_report.json").write_text(json.dumps(dist_report, indent=2))

    log.info("\n%s", format_report(report))
    log.info("repair_mode=%s  shipped_pristine=%d  repaired_passed=%d  (step=%d)  "
             "dropped_by_balance=%d  quarantined=%d  duplicates=%d",
             repair_mode, n_ship, n_repaired, n_step, n_drop, n_quar, n_dup)
    log.info("Manifest: %s  +  %s", pq, csv)

    return dist_report
