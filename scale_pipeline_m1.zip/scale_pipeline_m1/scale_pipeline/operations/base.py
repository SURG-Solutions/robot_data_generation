"""Operation plugin interface. Every augmentation (scale now; rotate/mirror/feature later)
implements this so the pipeline treats them uniformly."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class Variant:
    """One generated output before validation/dedup/balance."""
    mesh: object
    op: str
    params: dict
    suffix: str
    meta: dict = field(default_factory=dict)


class BaseOperation(ABC):
    name = "base"

    def is_enabled(self, cfg):
        return bool(cfg["operations"].get(self.name, {}).get("enabled", False))

    @abstractmethod
    def generate(self, mesh, source_meta, cfg):
        """Return a list[Variant] derived from one source mesh."""
        raise NotImplementedError
