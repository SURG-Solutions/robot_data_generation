"""Operation plugins. Milestone 1 ships scaling; M2/M3 add rotation/mirror/feature ops here."""

from .base import BaseOperation, Variant
from .scaling import Identity, ProportionalScaling, NonProportionalScaling, SmallPartUpscale


def build_operations(cfg):
    """Instantiate the enabled operations in run order.

    In repair-only mode the single Identity op runs (clean meshes, no scaling)."""
    if cfg.get("repair_only"):
        return [Identity()]
    registry = [ProportionalScaling(), NonProportionalScaling(), SmallPartUpscale()]
    return [op for op in registry if op.is_enabled(cfg)]


__all__ = [
    "BaseOperation", "Variant", "Identity",
    "ProportionalScaling", "NonProportionalScaling", "SmallPartUpscale",
    "build_operations",
]
