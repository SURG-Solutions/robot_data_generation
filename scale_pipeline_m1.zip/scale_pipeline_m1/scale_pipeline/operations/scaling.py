"""Scaling operations: proportional, non-proportional (incl. X/Y diagonal), small-part upscale."""

from .base import BaseOperation, Variant


def _scaled_copy(mesh, sx, sy, sz):
    m = mesh.copy()
    m.apply_scale([sx, sy, sz])
    return m


def _fmt(x):
    return str(x).rstrip("0").rstrip(".") if isinstance(x, float) else str(x)


class Identity(BaseOperation):
    """Pass the mesh through unscaled. Used by --repair-only to clean meshes without scaling."""
    name = "identity"

    def generate(self, mesh, source_meta, cfg):
        return [Variant(mesh.copy(), self.name, {}, "orig")]


class ProportionalScaling(BaseOperation):
    name = "proportional"

    def generate(self, mesh, source_meta, cfg):
        out = []
        for f in cfg["operations"]["proportional"]["factors"]:
            out.append(Variant(
                _scaled_copy(mesh, f, f, f),
                self.name, {"factor": float(f)}, f"prop_{_fmt(f)}x",
                {"tier": "standard"}))
        return out


class NonProportionalScaling(BaseOperation):
    name = "non_proportional"

    def generate(self, mesh, source_meta, cfg):
        out = []
        for combo in cfg["operations"]["non_proportional"]["combos"]:
            sx, sy, sz = (float(c) for c in combo)
            out.append(Variant(
                _scaled_copy(mesh, sx, sy, sz),
                self.name, {"sx": sx, "sy": sy, "sz": sz},
                f"nonprop_{_fmt(sx)}_{_fmt(sy)}_{_fmt(sz)}"))
        return out


class SmallPartUpscale(BaseOperation):
    name = "small_part_upscale"

    def generate(self, mesh, source_meta, cfg):
        c = cfg["operations"]["small_part_upscale"]
        out = []
        if source_meta.get("id") in set(cfg.get("protected_ids", [])):
            return out
        ext = [float(x) for x in mesh.extents]
        min_dim, max_dim = min(ext), max(ext)
        if min_dim >= c["threshold_mm"]:
            return out
        for f in c["factors"]:
            if max_dim * f > c["max_output_mm"]:
                continue
            out.append(Variant(
                _scaled_copy(mesh, f, f, f),
                self.name, {"factor": float(f), "tier": "large"}, f"upscale_{_fmt(f)}x",
                {"tier": "large"}))
        return out
