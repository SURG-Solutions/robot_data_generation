"""Resolve a source reference to a local file. Downloads (and caches) http(s) URLs;
local paths pass through unchanged."""

import hashlib
import urllib.parse
import urllib.request
from pathlib import Path


def is_url(s):
    s = str(s)
    return s.startswith("http://") or s.startswith("https://")


def _download(url, cache_dir):
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    ext = Path(urllib.parse.urlparse(url).path).suffix or ".bin"
    dest = cache_dir / (hashlib.sha256(url.encode()).hexdigest()[:16] + ext)
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    req = urllib.request.Request(url, headers={"User-Agent": "scale-pipeline/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    if not data:
        raise IOError(f"empty download: {url}")
    dest.write_bytes(data)
    return dest


def to_local(path_or_url, cache_dir):
    """Return a local filesystem path. Downloads to cache_dir if given a URL."""
    if is_url(path_or_url):
        return str(_download(str(path_or_url), cache_dir))
    return str(path_or_url)
