#!/usr/bin/env python
"""CLI entry: parquet of source models in -> validated, deduped, balanced scaled meshes out.

Examples:
  python scale_augment.py --input example/example.parquet --output-dir outputs
  python scale_augment.py --config config/default.yaml --no-upscale --seed 7
"""

import argparse
import logging
import sys
from pathlib import Path

from scale_pipeline import __version__
from scale_pipeline.config import load_config, ConfigError
from scale_pipeline import pipeline

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "config" / "default.yaml"


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description="Milestone 1 scaling-augmentation pipeline")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG), help="YAML config path")
    ap.add_argument("--input", help="input parquet (overrides config input.parquet)")
    ap.add_argument("--base-dir", help="base dir for resolving relative source paths")
    ap.add_argument("--output-dir", help="output dir (overrides config output.dir)")
    ap.add_argument("--seed", type=int, help="RNG seed for balancing subsample")
    ap.add_argument("--limit", type=int, help="process only the first N sources (trial runs)")
    ap.add_argument("--dry-run", action="store_true",
                    help="validate the parquet schema + resolve paths, then exit (no processing)")
    ap.add_argument("--repair-only", action="store_true",
                    help="clean/repair source meshes without scaling (no balance/dedup)")
    ap.add_argument("--print-config", action="store_true",
                    help="print the fully-resolved config (after CLI overrides) and exit")
    ap.add_argument("--quiet", action="store_true", help="only warnings and errors")
    ap.add_argument("--version", action="version", version=f"scale-pipeline {__version__}")
    ap.add_argument("--no-proportional", action="store_true", help="disable proportional scaling")
    ap.add_argument("--no-nonproportional", action="store_true", help="disable non-proportional scaling")
    ap.add_argument("--no-upscale", action="store_true", help="disable small-part upscale tier")
    ap.add_argument("--no-balance", action="store_true", help="disable size-bucket balancing")
    ap.add_argument("--no-dedup", action="store_true", help="disable dedup")
    ap.add_argument("--no-repair", action="store_true", help="disable mesh repair stage")
    ap.add_argument("--no-step", action="store_true", help="do not export scaled STEP files")
    ap.add_argument("--no-self-intersection", action="store_true", help="skip self-intersection check")
    ap.add_argument("-v", "--verbose", action="store_true")
    return ap.parse_args(argv)


def build_overrides(args):
    o = {}
    if args.input:               o["input.parquet"] = args.input
    if args.base_dir:            o["input.base_dir"] = args.base_dir
    if args.output_dir:          o["output.dir"] = args.output_dir
    if args.seed is not None:    o["seed"] = args.seed
    if args.limit is not None:   o["limit"] = args.limit
    if args.repair_only:
        o["repair_only"] = True
        o["balance.enabled"] = False
        o["dedup.enabled"] = False
    if args.no_proportional:     o["operations.proportional.enabled"] = False
    if args.no_nonproportional:  o["operations.non_proportional.enabled"] = False
    if args.no_upscale:          o["operations.small_part_upscale.enabled"] = False
    if args.no_balance:          o["balance.enabled"] = False
    if args.no_dedup:            o["dedup.enabled"] = False
    if args.no_repair:           o["repair.enabled"] = False
    if args.no_step:             o["output.export_step"] = False
    if args.no_self_intersection: o["validation.check_self_intersection"] = False
    return o


def main(argv=None):
    args = parse_args(argv)
    level = logging.WARNING if args.quiet else (logging.DEBUG if args.verbose else logging.INFO)
    logging.basicConfig(level=level, format="%(levelname)s %(message)s")
    try:
        cfg = load_config(args.config, build_overrides(args))
    except ConfigError as e:
        print(f"CONFIG ERROR: {e}", file=sys.stderr)
        return 2

    if args.print_config:
        import yaml
        print(yaml.safe_dump(cfg, sort_keys=False, default_flow_style=False))
        return 0

    from scale_pipeline.io_parquet import load_sources, SchemaError

    if args.dry_run:
        try:
            sources = load_sources(cfg)
        except SchemaError as e:
            print(f"SCHEMA ERROR: {e}", file=sys.stderr)
            return 2
        n_step = sum(1 for s in sources if str(s.get("step_path", "")).strip() not in ("", "nan", "None"))
        print(f"DRY RUN OK: {len(sources)} source rows resolved, {n_step} with STEP. "
              f"Schema and paths valid. Re-run without --dry-run to process.")
        return 0

    try:
        pipeline.run(cfg)
    except SchemaError as e:
        print(f"SCHEMA ERROR: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        logging.getLogger("scale_pipeline").error("Pipeline failed: %s", e)
        raise
    return 0


if __name__ == "__main__":
    sys.exit(main())
