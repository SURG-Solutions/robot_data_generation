"""Unit tests for the scaling math."""

import sys
from pathlib import Path
import numpy as np
import trimesh

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scale_pipeline.operations.scaling import (
    Identity, ProportionalScaling, NonProportionalScaling, SmallPartUpscale)
from scale_pipeline.operations import build_operations


def base_cfg():
    return {
        "operations": {
            "proportional": {"enabled": True, "factors": [0.5, 2.0]},
            "non_proportional": {"enabled": True, "combos": [[1.5, 1.5, 1.0], [1.0, 1.0, 2.0]]},
            "small_part_upscale": {"enabled": True, "threshold_mm": 300.0,
                                   "max_output_mm": 2000.0, "factors": [2.0, 10.0]},
        },
        "protected_ids": [],
    }


def box(extents):
    return trimesh.creation.box(extents=extents)


def test_proportional_scales_all_axes():
    m = box([100, 50, 20])
    out = ProportionalScaling().generate(m, {"id": "x"}, base_cfg())
    assert len(out) == 2
    v05 = next(v for v in out if v.params["factor"] == 0.5)
    np.testing.assert_allclose(sorted(v05.mesh.extents), [10, 25, 50], rtol=1e-6)
    v2 = next(v for v in out if v.params["factor"] == 2.0)
    np.testing.assert_allclose(sorted(v2.mesh.extents), [40, 100, 200], rtol=1e-6)


def test_nonproportional_xy_diagonal():
    m = box([100, 100, 40])
    out = NonProportionalScaling().generate(m, {"id": "x"}, base_cfg())
    diag = next(v for v in out if v.params == {"sx": 1.5, "sy": 1.5, "sz": 1.0})
    ext = diag.mesh.extents
    np.testing.assert_allclose(sorted(ext), sorted([150, 150, 40]), rtol=1e-6)


def test_upscale_only_small_parts():
    small = box([100, 80, 60])
    out = SmallPartUpscale().generate(small, {"id": "s"}, base_cfg())
    assert len(out) >= 1
    assert any(v.params["factor"] == 2.0 for v in out)


def test_upscale_skips_large_parts():
    large = box([400, 400, 350])
    out = SmallPartUpscale().generate(large, {"id": "L"}, base_cfg())
    assert out == []


def test_upscale_respects_max_output_cap():
    small = box([100, 100, 50])
    cfg = base_cfg()
    cfg["operations"]["small_part_upscale"]["factors"] = [2.0, 25.0]
    out = SmallPartUpscale().generate(small, {"id": "s"}, cfg)
    factors = [v.params["factor"] for v in out]
    assert 2.0 in factors and 25.0 not in factors


def test_upscale_skips_protected():
    small = box([100, 80, 60])
    cfg = base_cfg()
    cfg["protected_ids"] = ["s"]
    out = SmallPartUpscale().generate(small, {"id": "s"}, cfg)
    assert out == []


def test_identity_passes_mesh_unscaled():
    m = box([100, 50, 20])
    out = Identity().generate(m, {"id": "x"}, base_cfg())
    assert len(out) == 1
    np.testing.assert_allclose(sorted(out[0].mesh.extents), [20, 50, 100], rtol=1e-9)


def test_repair_only_uses_identity_only():
    cfg = base_cfg()
    cfg["repair_only"] = True
    ops = build_operations(cfg)
    assert [o.name for o in ops] == ["identity"]


def test_normal_mode_uses_scaling_ops():
    cfg = base_cfg()
    ops = build_operations(cfg)
    assert "identity" not in [o.name for o in ops]
    assert "proportional" in [o.name for o in ops]
