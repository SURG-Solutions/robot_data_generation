"""Unit tests for mesh-integrity validation."""

import sys
from pathlib import Path
import numpy as np
import trimesh

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scale_pipeline.validation import validate_mesh, make_self_intersection_checker


def cfg(**over):
    base = {
        "validation": {
            "require_watertight": False,
            "require_winding_consistent": True,
            "min_face_area": 1.0e-6,
            "max_degenerate_faces": 0,
            "check_self_intersection": False,
            "max_self_intersections": 0,
            "reject_nan_inf": True,
            "require_single_component": False,
            "reject_inverted_normals": True,
        }
    }
    base["validation"].update(over)
    return base


def test_clean_box_is_valid():
    m = trimesh.creation.box([100, 50, 20])
    flags = validate_mesh(m, cfg())
    assert flags["valid"] is True
    assert flags["watertight"] is True


def test_nan_inf_rejected():
    m = trimesh.creation.box([100, 50, 20])
    v = m.vertices.copy()
    v[0][0] = np.inf
    m2 = trimesh.Trimesh(vertices=v, faces=m.faces, process=False)
    flags = validate_mesh(m2, cfg())
    assert flags["nan_inf"] is True
    assert flags["valid"] is False
    assert "nan_inf" in flags["reasons"]


def test_degenerate_face_detected():
    verts = np.array([[0, 0, 0], [1, 0, 0], [2, 0, 0], [0, 1, 0]], dtype=float)
    faces = np.array([[0, 1, 2], [0, 1, 3]])
    m = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
    flags = validate_mesh(m, cfg())
    assert flags["degenerate_faces"] >= 1
    assert flags["valid"] is False
    assert "degenerate_faces" in flags["reasons"]


def test_watertight_not_required_by_default():
    verts = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=float)
    m = trimesh.Trimesh(vertices=verts, faces=np.array([[0, 1, 2]]), process=False)
    flags = validate_mesh(m, cfg(require_watertight=False))
    assert flags["watertight"] is False
    assert "not_watertight" not in flags["reasons"]


def test_watertight_required_rejects_open_mesh():
    verts = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=float)
    m = trimesh.Trimesh(vertices=verts, faces=np.array([[0, 1, 2]]), process=False)
    flags = validate_mesh(m, cfg(require_watertight=True))
    assert flags["valid"] is False
    assert "not_watertight" in flags["reasons"]


def test_self_intersection_checker_on_clean_mesh():
    chk = make_self_intersection_checker()
    if chk is None:
        return
    box = trimesh.creation.box([100, 50, 20])
    assert chk(box) == 0


def test_single_component_clean_box():
    m = trimesh.creation.box([100, 50, 20])
    flags = validate_mesh(m, cfg())
    assert flags["components"] == 1


def test_multiple_components_detected_and_rejected():
    a = trimesh.creation.box([10, 10, 10])
    b = trimesh.creation.box([10, 10, 10]); b.apply_translation([100, 0, 0])
    combined = trimesh.util.concatenate([a, b])
    flags = validate_mesh(combined, cfg(require_single_component=True))
    assert flags["components"] == 2
    assert flags["valid"] is False
    assert "multiple_components" in flags["reasons"]


def test_multiple_components_allowed_when_not_required():
    a = trimesh.creation.box([10, 10, 10])
    b = trimesh.creation.box([10, 10, 10]); b.apply_translation([100, 0, 0])
    combined = trimesh.util.concatenate([a, b])
    flags = validate_mesh(combined, cfg(require_single_component=False))
    assert flags["components"] == 2
    assert "multiple_components" not in flags["reasons"]


def test_inverted_normals_detected():
    m = trimesh.creation.box([100, 50, 20])
    m.invert()
    flags = validate_mesh(m, cfg(reject_inverted_normals=True))
    assert flags["normals_outward"] is False
    assert flags["valid"] is False
    assert "inverted_normals" in flags["reasons"]


def test_outward_normals_pass():
    m = trimesh.creation.box([100, 50, 20])
    flags = validate_mesh(m, cfg(reject_inverted_normals=True))
    assert flags["normals_outward"] is True
