"""Unit tests for URL/local source resolution."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scale_pipeline.fetch import is_url, to_local


def test_is_url():
    assert is_url("http://example.com/a.stl")
    assert is_url("https://example.com/a.stl")
    assert not is_url("/data/models/a.stl")
    assert not is_url("relative/a.stl")
    assert not is_url("C:\\models\\a.stl")


def test_to_local_passthrough_for_local_path(tmp_path):
    p = tmp_path / "a.stl"
    p.write_text("x")
    assert to_local(str(p), tmp_path / "cache") == str(p)


def test_to_local_downloads_url(tmp_path):
    import http.server, socketserver, threading, functools
    served = tmp_path / "served"
    served.mkdir()
    (served / "model.stl").write_bytes(b"solid test\nendsolid test\n")

    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(served))
    with socketserver.TCPServer(("127.0.0.1", 0), handler) as httpd:
        port = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        try:
            url = f"http://127.0.0.1:{port}/model.stl"
            local = to_local(url, tmp_path / "cache")
            assert Path(local).exists()
            assert Path(local).read_bytes() == b"solid test\nendsolid test\n"
            assert to_local(url, tmp_path / "cache") == local
        finally:
            httpd.shutdown()
