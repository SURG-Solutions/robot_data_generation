"""Unit tests for geometry-signature dedup."""

import sys
from pathlib import Path
import trimesh

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scale_pipeline.dedup import signature, Deduplicator


def cfg():
    return {"dedup": {"enabled": True, "vertex_decimals": 3, "bbox_round": 2, "volume_round": 2}}


def test_identical_meshes_same_signature():
    a = trimesh.creation.box([100, 50, 20])
    b = trimesh.creation.box([100, 50, 20])
    assert signature(a, cfg()) == signature(b, cfg())


def test_translation_invariant():
    a = trimesh.creation.box([100, 50, 20])
    b = a.copy()
    b.apply_translation([500, -300, 75])
    assert signature(a, cfg()) == signature(b, cfg())


def test_different_scale_different_signature():
    a = trimesh.creation.box([100, 50, 20])
    b = trimesh.creation.box([130, 65, 26])
    assert signature(a, cfg()) != signature(b, cfg())


def test_deduplicator_flags_repeat():
    d = Deduplicator(cfg())
    a = trimesh.creation.box([100, 50, 20])
    b = trimesh.creation.box([100, 50, 20])
    is_dup1, _, _ = d.check(a, "a")
    is_dup2, _, orig = d.check(b, "b")
    assert is_dup1 is False
    assert is_dup2 is True
    assert orig == "a"


def test_dedup_disabled_passes_everything():
    c = cfg(); c["dedup"]["enabled"] = False
    d = Deduplicator(c)
    a = trimesh.creation.box([100, 50, 20])
    assert d.check(a, "a")[0] is False
    assert d.check(a, "b")[0] is False
