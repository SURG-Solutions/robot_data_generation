"""Unit tests for STEP (BREP) scaling. Skipped automatically if CadQuery is absent."""

import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scale_pipeline import step_io


pytestmark = pytest.mark.skipif(not step_io.available(), reason="cadquery not installed")


def _bbox(solid):
    bb = solid.BoundingBox()
    return (bb.xlen, bb.ylen, bb.zlen)


def test_scale_vector_mapping():
    assert step_io.scale_vector_from_params("proportional", {"factor": 1.3}) == (1.3, 1.3, 1.3)
    assert step_io.scale_vector_from_params("small_part_upscale", {"factor": 4.0}) == (4.0, 4.0, 4.0)
    assert step_io.scale_vector_from_params(
        "non_proportional", {"sx": 1.5, "sy": 1.5, "sz": 1.0}) == (1.5, 1.5, 1.0)


def test_proportional_step_scale():
    import cadquery as cq
    solid = cq.Workplane().box(100, 50, 20).val()
    bx, by, bz = _bbox(solid)
    scaled = step_io.scale_step(solid, 1.3, 1.3, 1.3)
    sx, sy, sz = _bbox(scaled)
    assert abs(sx - bx * 1.3) < 1e-6
    assert abs(sy - by * 1.3) < 1e-6
    assert abs(sz - bz * 1.3) < 1e-6


def test_nonproportional_xy_diagonal_step_scale():
    import cadquery as cq
    solid = cq.Workplane().box(100, 100, 40).val()
    scaled = step_io.scale_step(solid, 1.5, 1.5, 1.0)
    sx, sy, sz = _bbox(scaled)
    assert abs(sx - 150) < 1e-6
    assert abs(sy - 150) < 1e-6
    assert abs(sz - 40) < 1e-6


def test_step_roundtrip(tmp_path):
    import cadquery as cq
    solid = cq.Workplane().box(100, 50, 20).val()
    scaled = step_io.scale_step(solid, 2.0, 2.0, 2.0)
    out = tmp_path / "scaled.step"
    step_io.save_step(scaled, out)
    assert out.exists() and out.stat().st_size > 0
    reloaded = step_io.load_step(out)
    sx, sy, sz = _bbox(reloaded)
    assert abs(sx - 200) < 1e-3
