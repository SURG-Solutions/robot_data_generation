"""Unit tests for the mesh-repair stage."""

import sys
from pathlib import Path
import numpy as np
import trimesh

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scale_pipeline.repair import repair_mesh
from scale_pipeline.validation import validate_mesh


def repair_cfg(**over):
    base = {
        "enabled": True,
        "use_pymeshlab": False,
        "merge_vertices": True,
        "remove_degenerate_faces": True,
        "degenerate_height": 1.0e-6,
        "remove_duplicate_faces": True,
        "remove_unreferenced_vertices": True,
        "fix_normals": True,
        "fill_holes": True,
        "resolve_self_intersections": False,
    }
    base.update(over)
    return {"repair": base}


def val_cfg():
    return {"validation": {
        "require_watertight": False, "require_winding_consistent": True,
        "min_face_area": 1.0e-6, "max_degenerate_faces": 0,
        "check_self_intersection": False, "max_self_intersections": 0,
        "reject_nan_inf": True}}


def test_repair_disabled_is_noop():
    m = trimesh.creation.box([10, 10, 10])
    out, actions = repair_mesh(m, {"repair": {"enabled": False, "use_pymeshlab": False}})
    assert actions == []
    assert len(out.faces) == len(m.faces)


def test_repair_removes_degenerate_faces():
    box = trimesh.creation.box([10, 10, 10])
    verts = np.vstack([box.vertices, [[20, 0, 0], [21, 0, 0], [22, 0, 0]]])
    n = len(box.vertices)
    faces = np.vstack([box.faces, [[n, n + 1, n + 2]]])
    dirty = trimesh.Trimesh(vertices=verts, faces=faces, process=False)

    before = validate_mesh(dirty, val_cfg())
    assert before["degenerate_faces"] >= 1

    fixed, actions = repair_mesh(dirty, repair_cfg())
    after = validate_mesh(fixed, val_cfg())
    assert after["degenerate_faces"] == 0


def test_repair_merges_duplicate_vertices():
    verts = np.array([
        [0, 0, 0], [1, 0, 0], [0, 1, 0],
        [0, 0, 0], [1, 0, 0], [1, 1, 0],
    ], dtype=float)
    faces = np.array([[0, 1, 2], [3, 4, 5]])
    m = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
    fixed, actions = repair_mesh(m, repair_cfg())
    assert len(fixed.vertices) < len(m.vertices)
    assert any("merged_vertices" in a for a in actions)


def test_repair_keeps_clean_mesh_valid():
    m = trimesh.creation.box([10, 10, 10])
    fixed, _ = repair_mesh(m, repair_cfg())
    flags = validate_mesh(fixed, val_cfg())
    assert flags["valid"] is True
